﻿using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Input;
namespace Population
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        VM vm = new VM();
        //Regular expression for positive integers.
        private const string REG_NUM = "[0-9]+";
        private const string REG_DOUBLE = "[0-9.]+";
        public MainWindow()
        {
            InitializeComponent();
            DataContext=vm;
        }
        //Button click to calculate data.
        private void BtnCalculate_Click(object sender, RoutedEventArgs e)
        {
            vm.Calculate();
        }
        //Button click to clear data.
        private void BtnReset_Click(object sender, RoutedEventArgs e)
        {
            vm.Clear();
        }
        // Restrict to enter only numbers.
        private void Input_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            Regex regex = new Regex(REG_NUM);
            e.Handled = !regex.IsMatch(e.Text);
        }
        // Restrict to enter only decimals.
        private void Input_DecimalPreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            Regex regex = new Regex(REG_DOUBLE);
            e.Handled = !regex.IsMatch(e.Text);
        }
        //Button click to calculate and save in file.
        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            vm.Calculate();
            vm.FileSave();
        }
    }
}
