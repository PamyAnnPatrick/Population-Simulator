﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Runtime.CompilerServices;
using System.Windows;

namespace Population
{
    class VM : INotifyPropertyChanged
    {
        const int SINGLE_WIDTH = 400;

        const int DOUBLE_WIDTH = 850;

        private const int CENTPERCENT = 100;

        private int startNumber;
        public int StartNumber { get { return startNumber; } set { startNumber = value; onChange(); } }

        private double populationPercent;
        public double PopulationPercent { get { return populationPercent; } set { populationPercent = value; onChange(); } }

        private string msgText;
        public string MsgText {get { return msgText; } set { msgText = value; onChange(); } }

        private int days;
        public int Days { get { return days; } set { days = value; onChange(); } }

        private int titleWidth = SINGLE_WIDTH;
        public int TitleWidth { get { return titleWidth; } set { titleWidth = value; onChange(); } }
        public BindingList<string> Population { get; set; } = new BindingList<string>();

        private List<KeyValuePair<int, int>> chartData;
        public List<KeyValuePair<int, int>> ChartData { get { return chartData; } set { chartData = value; onChange(); } }

        private Visibility chartVis = Visibility.Collapsed;
        public Visibility ChartVis { get { return chartVis; } set { chartVis = value; onChange(); } }

        private Visibility otherVis = Visibility.Collapsed;
        public Visibility OtherVis { get { return otherVis; } set { otherVis = value; onChange(); } }

        public string FileData;
        public void Clear()
        {
            MsgText = "";
            PopulationPercent = 0;
            Days = 0;
            StartNumber = 0;
            Population.Clear();
            ChartData = null;
            ChartVis = Visibility.Collapsed;
            OtherVis = Visibility.Collapsed;
            TitleWidth = SINGLE_WIDTH;
        }
        public void Calculate()
        {
            try
            {
                if (Validation())
                {
                    Population.Clear();
                    ChartData = null;
                    ChartVis = Visibility.Visible;
                    OtherVis = Visibility.Visible;
                    TitleWidth = DOUBLE_WIDTH;
                    double populationPrevDay = StartNumber;
                    //List to display data in Chart.
                    List<KeyValuePair<int, int>> currentDataList = new List<KeyValuePair<int, int>>();
                    FileData = $"The population of organism with average daily population ({PopulationPercent}%)\r\n";
                    int i = 0;
                    while (i <= Days)
                    {
                        double populationNextDay = (CENTPERCENT + PopulationPercent) * populationPrevDay / CENTPERCENT;
                        string eachDayString = $"Population of day {i} is {(int)populationPrevDay}";
                        //For adding value to the List box.
                        Population.Add(eachDayString);
                        //For adding value to the File.
                        FileData += eachDayString + "\r\n";
                        try
                        {
                            //For adding value to the Chart.
                            currentDataList.Add(new KeyValuePair<int, int>((int)populationPrevDay, i));
                        }
                        catch (Exception)
                        {
                            ChartVis = Visibility.Collapsed;
                        }
                        populationPrevDay = populationNextDay;
                        i++;
                    }                 
                    ChartData = currentDataList;
                }
            }
            catch (Exception)
            {
                Clear();
            }
        }
        //Validation to check all textboxes are filled.
        public bool Validation()
        {

            bool res = false;
            try
            {
                if (StartNumber > 0 && PopulationPercent > 0 && Days > 0)
                {
                    res = true;
                    MsgText = "";
                }
                else
                {
                    MsgText = "Enter all fields";
                }
            }
            catch (Exception)
            {
                Clear();
            }
            return res;
        }
        //Function to save file in selected folder.
        public void FileSave()
        {
            try
            {
                if (Validation())
                {
                    SaveFileDialog saveFileDialog = new SaveFileDialog();
                    if (saveFileDialog.ShowDialog() == true)
                    {
                        File.AppendAllText(saveFileDialog.FileName, FileData + "\r\n");
                    }
                }
            }
            catch (Exception)
            {
                Clear();
            }
        }
        #region PropertyChanged
        public event PropertyChangedEventHandler PropertyChanged;
        private void onChange([CallerMemberName] String propertyName = "")
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
        #endregion
    }
}
